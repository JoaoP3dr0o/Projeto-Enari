﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using static ProjBase1.Form3;
using static ProjBase1.Form4;


namespace ProjBase1
{
    public static class DadosGlobal
    {
        public static List<Postagem> FeedGeral { get; set; } = new List<Postagem>();
    }
    public partial class Form3 : Form
    {

        public Form3()
        {
            InitializeComponent();
            this.Text = "Orkit";

        }

        public class Postagem
        {
            public string Post { get; set; }
            public Image Imagem { get; set; }
            public List<string> Comentarios { get; set; } = new List<string>();
            public List<string> UsuariosQueCurtiram { get; set; } = new List<string>();

            // Construtor para inicializar a postagem
            public Postagem(string post, Image imagem)
            {
                Post = post;
                Imagem = imagem;
            }
        }


        //teste para adicionar amigo
       /*public static class DadosUsuario
        {
            public static Usuario UsuarioLogado { get; set; }
            public static Dictionary<string, Usuario> Usuarios { get; set; } = new Dictionary<string, Usuario>();
        
            public static void AdicionarAmigo(string nomeAmigo)
            {
                if (UsuarioLogado == null)
                {
                    MessageBox.Show("Nenhum usuário logado.");
                    return;
                }

                // Verifica se o amigo existe na lista de usuários
                if (Usuarios.ContainsKey(nomeAmigo))
                {
                    var amigo = Usuarios[nomeAmigo];

                    // Adiciona o amigo à lista de amigos do usuário logado, se ainda não for amigo
                    if (!UsuarioLogado.Amigos.Contains(amigo))
                    {
                        UsuarioLogado.Amigos.Add(amigo);
                        amigo.Amigos.Add(UsuarioLogado); // Torna a amizade mútua

                        MessageBox.Show($"{nomeAmigo} agora é seu amigo!");
                    }
                    else
                    {
                        MessageBox.Show("Esse usuário já é seu amigo.");
                    }
                }
                else
                {
                    MessageBox.Show("Usuário não encontrado.");
                }
            }
        }*/


        private void Form3_Load(object sender, EventArgs e)
        {
            
            if (DadosUsuario.UsuarioLogado != null && !string.IsNullOrEmpty(DadosUsuario.UsuarioLogado.Nome))
            {
                textBox1.Text = DadosUsuario.UsuarioLogado.Nome;
            }
            else
            {
                MessageBox.Show("Usuário não logado.");
                this.Hide();
                Form1 form = new Form1();
                form.Show();
            }

            AtualizarFeedGeral();

            if (DadosUsuario.UsuarioLogado.FotoPerfil != null)
            {
                pictureBox1.Image = DadosUsuario.UsuarioLogado.FotoPerfil;
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }

            
        }


        private void btProfile_Click(object sender, EventArgs e)
        {
            this.Hide();

            using (Form4 form = new Form4())
            {
                form.ShowDialog();
            }

            this.Show();

            AtualizarPosts();
            AtualizarFeedGeral();
            if (DadosUsuario.UsuarioLogado.FotoPerfil != null)
            {
                pictureBox1.Image = DadosUsuario.UsuarioLogado.FotoPerfil;
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        private void LimparDadosUsuario()
        {
            DadosUsuario.UsuarioLogado.Posts.Clear();
            DadosUsuario.UsuarioLogado.Imagens.Clear();

        }

        private void Logoff_Click(object sender, EventArgs e)
        {
            // Verifica se há um usuário logado antes de deslogar
            if (DadosUsuario.UsuarioLogado != null)
            {
                // Armazena o estado atual dos posts e imagens do usuário
                string nomeUsuario = DadosUsuario.UsuarioLogado.Nome;
                if (DadosUsuario.Usuarios.ContainsKey(nomeUsuario))
                {
                    DadosUsuario.Usuarios[nomeUsuario] = DadosUsuario.UsuarioLogado;
                }

                // Desassocia o usuário logado
                DadosUsuario.UsuarioLogado = null;
            }

            // Esconde a tela atual e abre a tela de login novamente
            this.Hide();
            Form1 form = new Form1();
            form.ShowDialog();
            this.Close();
        }


        private void AtualizarFeedGeral()
        {
            PostText.Controls.Clear();
            int yPosition = 10;
            int postPanelHeight = 160; // Aumentado para acomodar os botões

            // Acessa corretamente o feed geral como uma lista de Postagem
            for (int i = DadosGlobal.FeedGeral.Count - 1; i >= 0; i--)
            {
                Postagem post = DadosGlobal.FeedGeral[i];

                // Criação do painel para o post
                Panel postPanel = new Panel
                {
                    Size = new Size(PostText.Width - 20, postPanelHeight),
                    Location = new Point(10, yPosition),
                    BorderStyle = BorderStyle.FixedSingle
                };

                // Adiciona a imagem do post
                PictureBox postImage = new PictureBox
                {
                    Image = post.Imagem,  // Acessa a imagem da postagem
                    SizeMode = PictureBoxSizeMode.StretchImage,
                    Size = new Size(100, 100),
                    Location = new Point(10, 10)
                };

                // Adiciona o texto do post
                Label postLabel = new Label
                {
                    Text = post.Post,  // Acessa o texto da postagem
                    AutoSize = true,
                    Location = new Point(120, 10),
                    MaximumSize = new Size(postPanel.Width - 130, 0),
                    Font = new Font("Arial", 14, FontStyle.Bold)
                };

                // Botão de curtir
                Button likeButton = new Button
                {
                    Text = "Curtir",
                    Location = new Point(120, 70),
                    Size = new Size(60, 25)
                };

                // Contador de likes
                Label likeCountLabel = new Label
                {
                    Text = $"{post.UsuariosQueCurtiram.Count} Likes",  // Acessa a lista de usuários que curtiram
                    Location = new Point(190, 75),
                    AutoSize = true
                };

                // Evento para curtir e descurtir o post
                likeButton.Click += (s, e) =>
                {
                    // Checa se o usuário já curtiu
                    if (post.UsuariosQueCurtiram.Contains(DadosUsuario.UsuarioLogado.Nome))
                    {
                        // Descurtir
                        post.UsuariosQueCurtiram.Remove(DadosUsuario.UsuarioLogado.Nome);
                        likeButton.BackColor = System.Drawing.Color.Gray;  // Cor ao descurtir
                        likeButton.Text = "Curtir";

                    }
                    else
                    {
                        // Curtir
                        post.UsuariosQueCurtiram.Add(DadosUsuario.UsuarioLogado.Nome);
                        likeButton.BackColor = System.Drawing.Color.Black;  // Cor ao curtir
                        likeButton.ForeColor = System.Drawing.Color.White;
                        likeButton.Text = "Curtido";
                    }

                    // Atualiza o contador de likes
                    likeCountLabel.Text = $"{post.UsuariosQueCurtiram.Count} Likes";

                    // Força o botão a redesenhar para refletir a mudança de cor
                    likeButton.Invalidate();  // Redesenha o botão
                    likeButton.Update();      // Força a atualização imediata do botão
                };


                // Botão de comentar
                Button commentButton = new Button
                {
                    Text = "Comentar",
                    Location = new Point(250, 70),
                    Size = new Size(80, 25)
                };

                // Evento para comentar
                commentButton.Click += (s, e) =>
                {
                    List<string> comentariosDoPost = post.Comentarios;

                    using (var commentForm = new CommentForm(comentariosDoPost))
                    {
                        if (commentForm.ShowDialog() == DialogResult.OK)
                        {
                            // O comentário já deve ter sido adicionado aqui
                            MessageBox.Show("Comentário adicionado!", "Sucesso", MessageBoxButtons.OK);

                            // Agora atualiza o feed para exibir o novo comentário
                            AtualizarFeedGeral();
                        }
                    }
                };



                // Exibir os comentários
                Label commentsLabel = new Label
                {
                    Text = string.Join("\n", post.Comentarios),
                    AutoSize = true,
                    Location = new Point(10, 120),
                    MaximumSize = new Size(postPanel.Width - 20, 0)
                };

                // Adiciona os controles ao painel do post
                postPanel.Controls.Add(postImage);
                postPanel.Controls.Add(postLabel);
                postPanel.Controls.Add(likeButton);
                postPanel.Controls.Add(likeCountLabel);
                postPanel.Controls.Add(commentButton);
                postPanel.Controls.Add(commentsLabel);

                // Adiciona o painel ao container principal
                PostText.Controls.Add(postPanel);
                yPosition += postPanelHeight + 10;
            }
        }





        private void AtualizarPosts()
        {
            PostText.Controls.Clear();
            int yPosition = 10;
            int postPanelHeight = 120;

            if (DadosUsuario.UsuarioLogado.Posts.Count != DadosUsuario.UsuarioLogado.Imagens.Count)
            {
                MessageBox.Show("Erro: O número de posts e imagens não coincide.");
                return;
            }

            for (int i = DadosUsuario.UsuarioLogado.Posts.Count - 1; i >= 0; i--)
            {
                var post = DadosUsuario.UsuarioLogado.Posts[i];
                var img = DadosUsuario.UsuarioLogado.Imagens[i];

                Panel postPanel = new Panel
                {
                    Size = new Size(PostText.Width - 20, postPanelHeight),
                    Location = new Point(10, yPosition),
                    BorderStyle = BorderStyle.FixedSingle
                };

                PictureBox postImage = new PictureBox
                {
                    Image = img,
                    SizeMode = PictureBoxSizeMode.StretchImage,
                    Size = new Size(100, 100),
                    Location = new Point(10, 10)
                };

                Label postLabel = new Label
                {
                    Text = post,
                    AutoSize = true,
                    Location = new Point(120, 10),
                    MaximumSize = new Size(postPanel.Width - 130, 0)
                };

                postPanel.Controls.Add(postImage);
                postPanel.Controls.Add(postLabel);
                PostText.Controls.Add(postPanel);
                yPosition += postPanelHeight + 10;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6();
            form6.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}