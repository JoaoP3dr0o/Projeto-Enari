﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Runtime.CompilerServices;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static ProjBase1.Form4;

namespace ProjBase1
{
    public partial class Form1 : Form
    {
        Thread t1;
     

        public static string UsuarioLogado { get; set; }


        public Form1()
        {
            InitializeComponent();
            this.Text = "Orkit";
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        


        private void button1_Click(object sender, EventArgs e)
        {
            string nomeUsuario = textEmail.Text;
            string senhaUsuario = textPassword.Text;  // Captura a senha fornecida pelo usuário

            // Verifica se o login foi bem-sucedido
            if (Login(nomeUsuario, senhaUsuario))
            {
                // Somente se o login for bem-sucedido, esconder o formulário e abrir o próximo
                this.Hide();
                Form3 form3 = new Form3();
                form3.Show();
            }

            

        }


        private bool Login(string nomeUsuario, string senhaUsuario)
        {
            // Verifica se o usuário e a senha estão na lista encadeada
            string[] usuarioEncontrado = FindUser(nomeUsuario, senhaUsuario);

            if (usuarioEncontrado != null)
            {
                string nomeUsuarioEncontrado = usuarioEncontrado[0];

                // Verifica se o usuário já existe no dicionário de usuários e carrega seus dados
                if (DadosUsuario.Usuarios.ContainsKey(nomeUsuarioEncontrado))
                {
                    DadosUsuario.UsuarioLogado = DadosUsuario.Usuarios[nomeUsuarioEncontrado];
                }
                else
                {
                    // Se o usuário não estiver no dicionário, cria um novo
                    DadosUsuario.UsuarioLogado = new Usuario { Nome = nomeUsuarioEncontrado, Senha = usuarioEncontrado[1] };
                    DadosUsuario.Usuarios[nomeUsuarioEncontrado] = DadosUsuario.UsuarioLogado; // Adiciona ao dicionário
                }

                return true; // Login bem-sucedido
            }

            else
            {
                // Exibir uma mensagem de erro se o usuário ou a senha estiverem incorretos
                MessageBox.Show("Usuário ou senha incorretos. Por favor, tente novamente.");
                return false; // Login falhou
            }
        }






        private string[] FindUser(string nome, string senha)
        {
            var atual = Form2.cabeca;

            while (atual != null)
            {
                if (atual.Dados[0] == nome && atual.Dados[1] == senha)
                {
                    return atual.Dados;
                }
                atual = atual.Proximo;
            }
            return null;
        }


        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btCadastrar_Click(object sender, EventArgs e)
        {

            this.Close();
            t1 = new Thread(OpenW);
            t1.SetApartmentState(ApartmentState.STA);
            t1.Start();


        }

        private void OpenW(object obj)
        {

            Application.Run(new Form2());

        }
        private void OpenW2(object obj)
        {

            Application.Run(new Form3());

        }

    }
}
