﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ProjBase1
{
    public partial class Form6 : Form
    {
        private int correctAnswer;
        private int score = 0;
        private string currentOperation;
        private Timer timer; // Adicionando um temporizador

        public Form6()
        {
            InitializeComponent();
            GenerateQuestion();
            op1.Click += new EventHandler(op1_Click);
            op2.Click += new EventHandler(op2_Click);
            op3.Click += new EventHandler(op3_Click);

            // Inicializando o temporizador
            timer = new Timer();
            timer.Interval = 1000; // 1 segundo
            timer.Tick += Timer_Tick;
        }

        private void GenerateQuestion()
        {
            op1.BackColor = SystemColors.Control; // Cor padrão
            op2.BackColor = SystemColors.Control;
            op3.BackColor = SystemColors.Control;

            // Gera uma nova pergunta
            Random random = new Random();
            int num1 = random.Next(1, 10);
            int num2 = random.Next(1, 10);
            int operationType = random.Next(0, 4);

            switch (operationType)
            {
                case 0:
                    correctAnswer = num1 + num2;
                    currentOperation = "+";
                    break;
                case 1:
                    correctAnswer = num1 - num2;
                    currentOperation = "-";
                    break;
                case 2:
                    correctAnswer = num1 * num2;
                    currentOperation = "*";
                    break;
                case 3:
                    while (num2 == 0 || num1 % num2 != 0)
                    {
                        num1 = random.Next(1, 10);
                        num2 = random.Next(1, 10);
                    }
                    correctAnswer = num1 / num2;
                    currentOperation = "/";
                    break;
            }

            richTextBox1.Text = $"Quanto é {num1} {currentOperation} {num2}?";

            int[] options = new int[3];
            int correctOption = random.Next(0, 3);
            options[correctOption] = correctAnswer; // Atribui a resposta correta

            for (int i = 0; i < 3; i++)
            {
                if (i != correctOption)
                {
                    int wrongAnswer;
                    do
                    {
                        wrongAnswer = random.Next(1, 20); // Gera uma resposta errada
                    } while (wrongAnswer == correctAnswer || Array.Exists(options, element => element == wrongAnswer));

                    options[i] = wrongAnswer; // Atribui uma resposta errada
                }
            }

            op1.Text = options[0].ToString();
            op2.Text = options[1].ToString();
            op3.Text = options[2].ToString();
        }

        private void CheckAnswer(int selectedAnswer)
        {
            // Desabilita os botões para prevenir múltiplos cliques
            op1.Enabled = false;
            op2.Enabled = false;
            op3.Enabled = false;

            // Verifica se a resposta está correta
            if (selectedAnswer == correctAnswer)
            {
                score++;
                HighlightCorrectButton(selectedAnswer);
                timer.Start();
            }
            else
            {
                HighlightWrongAndCorrectButtons(selectedAnswer);
                score = 0;
                timer.Start();
            }

            UpdateScore(); // Atualiza a pontuação
        }


        private void HighlightCorrectButton(int selectedAnswer)
        {
            // Destaca o botão correto
            if (selectedAnswer == int.Parse(op1.Text))
            {
                op1.BackColor = Color.Green;
            }
            else if (selectedAnswer == int.Parse(op2.Text))
            {
                op2.BackColor = Color.Green;
            }
            else if (selectedAnswer == int.Parse(op3.Text))
            {
                op3.BackColor = Color.Green;
            }

            // Gera nova pergunta após 1 segundo
            timer.Interval = 700; // 1 segundo
            //timer.Start();
        }

        private void HighlightWrongAndCorrectButtons(int selectedAnswer)
        {
            // Destaca o botão incorreto
            if (selectedAnswer == int.Parse(op1.Text))
            {
                op1.BackColor = Color.Red;
            }
            else if (selectedAnswer == int.Parse(op2.Text))
            {
                op2.BackColor = Color.Red;
            }
            else if (selectedAnswer == int.Parse(op3.Text))
            {
                op3.BackColor = Color.Red;
            }

            // Destaca o botão correto
            if (correctAnswer == int.Parse(op1.Text))
            {
                op1.BackColor = Color.Green;
            }
            else if (correctAnswer == int.Parse(op2.Text))
            {
                op2.BackColor = Color.Green;
            }
            else if (correctAnswer == int.Parse(op3.Text))
            {
                op3.BackColor = Color.Green;
            }
        }


        private void Timer_Tick(object sender, EventArgs e)
        {
            timer.Stop(); // Para o temporizador
            GenerateQuestion(); // Gera uma nova pergunta
            op1.Enabled = true;
            op2.Enabled = true;
            op3.Enabled = true;
        }

        private void UpdateScore()
        {
            labelScore.Text = $"Pontuação: {score}"; // Exibe a pontuação atual
        }

        private void op1_Click(object sender, EventArgs e)
        {
            int selectedAnswer;
            if (int.TryParse(op1.Text, out selectedAnswer))
            {
                CheckAnswer(selectedAnswer);
            }
            else
            {
                MessageBox.Show("Erro na conversão da resposta.");
            }
        }

        private void op2_Click(object sender, EventArgs e)
        {
            int selectedAnswer;
            if (int.TryParse(op2.Text, out selectedAnswer))
            {
                CheckAnswer(selectedAnswer);
            }
            else
            {
                MessageBox.Show("Erro na conversão da resposta.");
            }
        }

        private void op3_Click(object sender, EventArgs e)
        {
            int selectedAnswer;
            if (int.TryParse(op3.Text, out selectedAnswer))
            {
                CheckAnswer(selectedAnswer);
            }
            else
            {
                MessageBox.Show("Erro na conversão da resposta.");
            }
        }
    }
}
