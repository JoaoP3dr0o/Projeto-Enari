﻿namespace ProjBase1
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.op1 = new System.Windows.Forms.Button();
            this.op2 = new System.Windows.Forms.Button();
            this.op3 = new System.Windows.Forms.Button();
            this.labelScore = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.Enabled = false;
            this.richTextBox1.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.Location = new System.Drawing.Point(257, 103);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(247, 42);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            // 
            // op1
            // 
            this.op1.Location = new System.Drawing.Point(88, 177);
            this.op1.Name = "op1";
            this.op1.Size = new System.Drawing.Size(156, 46);
            this.op1.TabIndex = 1;
            this.op1.Text = "1";
            this.op1.UseVisualStyleBackColor = true;
            // 
            // op2
            // 
            this.op2.Location = new System.Drawing.Point(300, 177);
            this.op2.Name = "op2";
            this.op2.Size = new System.Drawing.Size(156, 46);
            this.op2.TabIndex = 2;
            this.op2.Text = "2";
            this.op2.UseVisualStyleBackColor = true;
            //this.op2.Click += new System.EventHandler(this.op2_Click_1);
            // 
            // op3
            // 
            this.op3.Location = new System.Drawing.Point(515, 177);
            this.op3.Name = "op3";
            this.op3.Size = new System.Drawing.Size(156, 46);
            this.op3.TabIndex = 3;
            this.op3.Text = "3";
            this.op3.UseVisualStyleBackColor = true;
            this.op3.Click += new System.EventHandler(this.op3_Click);
            // 
            // labelScore
            // 
            this.labelScore.AutoSize = true;
            this.labelScore.Enabled = false;
            this.labelScore.Location = new System.Drawing.Point(442, 305);
            this.labelScore.Name = "labelScore";
            this.labelScore.Size = new System.Drawing.Size(0, 16);
            this.labelScore.TabIndex = 4;
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.labelScore);
            this.Controls.Add(this.op3);
            this.Controls.Add(this.op2);
            this.Controls.Add(this.op1);
            this.Controls.Add(this.richTextBox1);
            this.Name = "Form6";
            this.Text = "Form6";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button op1;
        private System.Windows.Forms.Button op2;
        private System.Windows.Forms.Button op3;
        private System.Windows.Forms.Label labelScore;
    }
}