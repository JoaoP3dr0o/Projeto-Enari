﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ProjBase1
{
    public partial class CommentForm : Form
    {
        public string CommentText { get; private set; }

        // Lista para armazenar comentários
        private List<string> comentarios;

        public CommentForm(List<string> comentarios)
        {
            InitializeComponent();
            this.Text = "Adicionar Comentário";
            this.comentarios = comentarios; // Inicializa a lista de comentários

            // Adicione um TextBox e um Button para o comentário
            TextBox textBoxComentario = new TextBox
            {
                Location = new System.Drawing.Point(10, 10),
                Width = 200
            };
            this.Controls.Add(textBoxComentario);

            Button btnSalvar = new Button
            {
                Text = "Salvar",
                Location = new System.Drawing.Point(220, 10)
            };
            this.Controls.Add(btnSalvar);

            btnSalvar.Click += (s, e) =>
            {
                CommentText = textBoxComentario.Text;

                // Adiciona o comentário à lista se não estiver vazio
                if (!string.IsNullOrWhiteSpace(CommentText))
                {
                    comentarios.Add(CommentText);
                    MessageBox.Show("Comentário adicionado!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Por favor, insira um comentário válido.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                this.DialogResult = DialogResult.OK;
                this.Close();
            };


        }

        private void CommentForm_Load(object sender, EventArgs e)
        {
            // Lógica a ser executada quando o formulário carregar, se necessário
        }
    }
}